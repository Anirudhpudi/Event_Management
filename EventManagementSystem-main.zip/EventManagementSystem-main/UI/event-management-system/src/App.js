import React from 'react';
import EventList from './EventList';

function App() {
  return (
    <div className="App">
      <EventList />
    </div>
  );
}

export default App;
